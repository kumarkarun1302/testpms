<!-- Footer Top Section Starts -->
<section class="footer-top">
	<!-- Nested Container Starts -->
	<div class="container text-center-xs text-lite-color">
		<!-- Nested Row Starts -->
		<div class="row">
			<!-- Foot Col #1 Starts -->
			<div class="col-md-2 col-sm-6 col-xs-12">
				<div class="foot-info">
					<p>
						<img src="<?php echo base_url();?>images/logo_t.png" alt="UNO Financial Services " class="img-responsive img-center-xs">
					</p>
					<br>
					
					<!-- <ul class="list-unstyled list-inline foot-sm-links">
						<li class="text-medium">Follow Us:</li>
						<li><a href="#"><i class="fa fa-facebook animation"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter animation"></i></a></li>
						<li><a href="#"><i class="fa fa-google-plus animation"></i></a></li>
						<li><a href="#"><i class="fa fa-instagram animation"></i></a></li>
						<li><a href="#"><i class="fa fa-pinterest-p animation"></i></a></li>
					</ul>-->
				</div>
			</div>
			<!-- Foot Col #1 Ends -->
			<!-- Foot Col #2 Starts -->
			<div class="col-md-4 col-sm-6 col-xs-12">
				<a href="<?php echo base_url();?>contact"><h5>United States</h5></a>
				<ul class="list-unstyled foot-address-list text-light">
					<li class="clearfix">
						<i class="fa fa-map-marker"></i> 
						<span>
							<strong>206 Harmon Cove Towers, </strong><br>
							<strong>Secaucus, NJ - 07094</strong>
						</span>
					</li>
					<li class="clearfix">
						<i class="fa fa-phone"></i> 
						<span class="text-bold">+1(863)UNO-TEAM, +1 (201) 266-0444 </span>
					</li>
					<li class="clearfix">
						<i class="fa fa-envelope"></i> 
						<span><a href="mailto:contact@unofinancials.com">contact@unofinancials.com</a></span>
					</li>
					<li class="clearfix">
						<i class="fa fa-clock-o"></i> 
						<span>
							Mon - Fri : 8:00AM - 10:00PM (CST) <br>
							Sat - Sun : 8:00AM - 11:00PM (CST)  
						</span>
					</li>
				</ul>
				<br/>
				<h5>India</h5>
				<ul class="list-unstyled foot-address-list text-light">
					<li class="clearfix">
						<i class="fa fa-map-marker"></i> 
						<span>
							<strong>Parvathaneni & Associates  </strong><br>
							 Flat No.101, Plot No.93,<br/>
								Narayana Orchid Apartments<br/> 
								Road No.2, Kakateeya hills,<br/>
							Madhapur, Hyderabad - 500081. 
						</span>
					</li>
					<li class="clearfix">
						<i class="fa fa-phone pull-left"></i> 
						
						<span class="pull-left"> Phone: +91-40402 06567       
						<br>&emsp;&emsp;&emsp; +91 98664 79567   </span>
					</li>
					<li class="clearfix">
						<i class="fa fa-envelope"></i> 
						<span><a href="mailto:contact@unofinancials.com">contact@unofinancials.com</a></span>
					</li>
					
				</ul>
			</div>
			<!-- Foot Col #2 Ends -->
			<!-- Divider Starts -->
			<div class="col-xs-12 hidden visible-sm">
				<p><br><br></p>
			</div>
			<!-- Divider Ends -->
			<!-- Foot Col #3 Starts -->
			<div class="col-md-3 col-sm-6 col-xs-12">
				<h5>United States</h5>
				<ul class="list-unstyled foot-list-style-1 text-light">
					<li>Tax Return Preparation</li>
					<li>Incroporations</li>
					<li>Accounting Services</li>
					<li>Payroll Services</li>
					
				</ul>
			</div>
			<!-- Foot Col #3 Ends -->
			<!-- Foot Col #4 Starts -->
			<div class="col-md-3 col-sm-6 col-xs-12">
				<h5>India</h5>
				<ul class="list-unstyled foot-list-style-1 text-light">
					<li>Registrations & Incorporations</li>
					<li>Taxation Services</li>
					<li>Accounting Services</li>
					<li>Audit Services</li>
					<li>Payroll Services</li>
					<li>Bookkeeping Services</li>
				</ul>
			</div>
			<!-- Foot Col #4 Ends -->
		</div>
		<!-- Nested Row Ends -->
	</div>
	<!-- Nested Container Ends -->
</section>
<!-- Footer Top Section Ends -->
<!-- Copyright Starts -->
<footer class="copyright">
	<!-- Nested Container Starts -->
	<div class="container text-center text-lite-color">
		<a href="https://www.unofinancials.com/about">About Us</a> &nbsp; | &nbsp; <a href="<?php echo base_url();?>termsandconditions">Terms & Condition</a>&nbsp; | &nbsp; <a href="<?php echo base_url();?>privacy">Privacy Policy</a> | &nbsp; <a href="<?php echo base_url();?>disclaimer">Disclaimer</a> </p>
						<p>
	</div>
	<div class="container text-center text-lite-color">
		<em class="text-light">UNO Financial Services &copy; 2016. All Rights Reserved. </em>
	</div>
	<!-- Nested Container Ends -->
</footer>










<!-- Copyright Ends	-->
<!-- Template JS Files -->
<script src="<?php echo base_url();?>js/jquery-1.12.4.min.js"></script>
<script src="<?php echo base_url();?>js/jquery-migrate-1.4.1.min.js"></script>	
<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>js/plugins/backstretch/jquery.backstretch.min.js"></script>
<script src="<?php echo base_url();?>js/plugins/shuffle/jquery.shuffle.modernizr.min.js"></script>
<script src="<?php echo base_url();?>js/plugins/owl-carousel/owl.carousel.js"></script>
<script src="<?php echo base_url();?>js/plugins/magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="<?php echo base_url();?>js/custom.js"></script>	

<script type="text/javascript" src="<?php echo base_url();?>fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />



<script type="text/javascript">
	$(document).ready(function() {
		/*
			*  Simple image gallery. Uses default settings
		*/
		
		$('.fancybox').fancybox();
		
		
		$(".various").fancybox({
			maxWidth	: 800,
			maxHeight	: 600,
			fitToView	: false,
			width		: '60%',
			height		: '30%',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'none',
			closeEffect	: 'none'
		});
		$(".various1").fancybox({
			maxWidth	: 800,
			maxHeight	: 600,
			fitToView	: false,
			width		: '60%',
			height		: 'auto',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'elastic',
			closeEffect	: 'elastic'
		});
		
	});
	
	function openyoutube()
	{    //alert("");
		
		$('#1111').fancybox().trigger('click');
		
		
	}
</script>
</body>
</html>