<!DOCTYPE html>

<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <head>
        <!-- Title -->
        <title>Care and Cure</title>
        <style type="text/css">
		.flashscreen{width:600px; margin:20px auto; border:1px solid #ddd; border-radius:5px; background-color:#f6f6f6; padding:20px; font-family:sans-serif;}
		.flashscreen h2{color:#66a533; font-family:sans-serif; text-align:center;}
		.flashscreen img{ width:260px;}
		.flashscreen .lft{float:left; width:50%;}
		.flashscreen .rght{float:left; width:50%;}
		.flashscreen ul{
		list-style-type:none;
		padding-left:0px;
		}
		.flashscreen ul li{
			background:url('tick.png') no-repeat;
			text-indent:35px;
			line-height:30px;
		}
		</style>
    </head>
    <body>
        <div class="flashscreen" style="">
		<h2>Now you can download our apps on</h2>
		<div class="lft">
		<a target="_blank" href="https://play.google.com/store/apps/details?id=com.ionicframework.careandcure1">
		<img src="google-play-badge.png"/></a>
		<ul>
		<li>Listen Live Radio</li>
		<li>Ask our Expert</li>
		</ul>
		</div>
		<div class="rght">
		<a target="_blank" href="https://itunes.apple.com/us/app/care-and-cure/id1231830007?ls=1&mt=8"><img src="ios.png"/></a>
		<ul>
		<li>Schedule Appointment</li>
		<li>order online</li>
		</ul>
		</div>
		<div style="clear:both;"></div>
		</div>
	</body>
</html>