$client = new WC_API_Client( 'http://careandcure.co.uk', 

'ck_2701e1eac94cf30f58f08706a7ed16c4f0752714', 


'cs_fb2af7511771b1d8e691ac5439211666229c2879', $options );