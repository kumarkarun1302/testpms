<?php 
	
	//print_r($_SERVER) ;
	$url='http://www.careandcure.co.uk';
	/*if($_SERVER['HTTP_HOST']=='localhost:88')
	{
		$url='http://localhost:88/phpprojects/careandcure/';
	}
	*/
	
	//$url='http://localhost:88/phpprojects/careandcure/';
	
?>