<?php 
	
	
	
	
	
	include_once('../wp-config.php');
	
	
	
	$servername = DB_HOST;
	$username =DB_USER;
	$password =DB_PASSWORD;
	$dbname =DB_NAME;
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	$sql = "SELECT * FROM radio_feeds ORDER BY created_datetime DESC limit 0,1";
	$result = $conn->query($sql);
	
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			echo  $row["title"]."<br><br><br>";
			
			?>
			<audio controls autoplay loop>
				
				<source   src="<?php echo get_site_url(); ?>/radiofeeds/<?php echo $row["id"];?>.mp3" type="audio/mpeg">
				Your browser does not support the audio element.
			</audio>
			
			<div id="mask"></div>
			
		 	
<style>
	
	audio::-internal-media-controls-download-button {
    display:none;
	}
	
	audio::-webkit-media-controls-enclosure {
    overflow:hidden;
	}
	
	audio::-webkit-media-controls-panel {
    width: calc(100% + 30px); /* Adjust as needed */
	}
	
</style> 
			
			<?php 
		}
		} else {
		
	}
	$conn->close();
	
?>