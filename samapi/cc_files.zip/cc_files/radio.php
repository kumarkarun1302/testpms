<div class="cc_player" data-username="venujakku">Loading ...</div>
		<script language="javascript" type="text/javascript" src="https://control.internet-radio.com:2199/system/player.js"></script>