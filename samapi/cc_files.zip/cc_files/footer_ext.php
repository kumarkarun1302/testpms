<script type="text/javascript" src="<?php echo get_home_url(); ?>/cc_files/fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="<?php echo get_home_url(); ?>/cc_files/fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />
<!--<a href="sssssssssssssssss" class="simplemodal-login">Log In</a>
	
	
	<a href="" class="popmake-appointment-form">dddddddd</a>
<a href="http://click2dial.org/u/c2hhaDU1NTg5QGdtYWlsLmNvbQ=="> Test call</a>-->

<?php 
	if(isset($_GET['temp']))
	{?>
	
	<style>
		
		.container_inner
		{
		width:100%!important;
		margin-top: -16px!important;
		}
	</style>
	
	
	
	
	<?php 
		
		
	}
	
	
?>
<!--
	<a class="rightboxorangeradious1  ccaskourexpertbuttonright fancybox.iframe" href="http://careandcure.co.uk/cc_files/appointment/formpopupquestions.php"  href="javascript:void(0)"  > 		
	
	ASK OUR EXPERT  
	
	
	</a>
	
	<a class="rightboxorangeradiousappointment  ccaskourexpertbuttonrightappointment fancybox.iframe" href="http://careandcure.co.uk/cc_files/appointment/formpopup.php"  href="javascript:void(0)"  > 		
	
	SCHEDULE APPOINTMENT 
	
	
	</a>  
-->
<!--
	<a class="leftboxorangeradiousappointment  radiorightappointment fancybox.iframe  " href="http://careandcure.co.uk/radio.php"  href="javascript:void(0)"  > 		
	
	<img id="radioimage" src="cc_files/radio.png" style="width:32px"/>
	
	
	</a>
	
	--> <!--
	<a class="rightcallusbutton2  ccaskourexpertbuttonright " target="_blank" href="http://click2dial.org/u/c2hhaDU1NTg5QGdtYWlsLmNvbQ=="  href="javascript:void(0)"  > 		
	
	Call us2
	
	
</a> -->
<!--
	
	<a class="rightcallusbutton  ccaskourexpertbuttonright btn btn-large btn-success radiorightappointment2 fancybox.iframe" target="_blank" href="http://click2dial.org/u/c2hhaDU1NTg5QGdtYWlsLmNvbQ=="  href="javascript:void(0)"  > 		
	
	<strong>Call us free now </strong>&raquo;
	
	
	</a>
-->
<?php 
	if(!isset($_GET["temp"]))
	{
		
		
		
		
		
		$radion_live="false";
		date_default_timezone_set("Europe/London");
		
		//date_default_timezone_set("Asia/Kolkata");
		//echo date('H');
		$result = $wpdb->get_results ( "SELECT * FROM radio_time" );
		//print_r($result);
		foreach ( $result as $print )   {
			$day=$print->day;
			$start_time=$print->start_time;
			$end_time=$print->end_time;
			$play_offline=$print->off_pl_yes;
		}
		
		
		if(date("l")==$day){
		//echo date('H');
		
			if(date('H')>=$start_time && date('H')<=$end_time){
				//echo "Time is between 12PM to 4PM";
				$radion_live="true";
				echo "day2";
				
			}
			else{
				//echo "Open b/w 12pm to 4pm only";
				$radion_live="false";
			}
		}
		else {
			//echo "Today is not Monday";
			$radion_live="false";
		}
		  $radion_live="true";
		//echo $radion_live.'--------test---';
		if($radion_live=="false")
		{
		?>
		<!--<div  class="leftboxorangeradiousappointment     ">
			<a class="  radiorightappointment2   "   href="javascript:void(0)"  > 		
			<div id="radioimage3"  style="color:red;font-weight:bold;font-size:14px">Live Radio</div>
			<img style="    padding-left: 28px;width:16px" src="http://careandcure.co.uk/cc_files/radio.png" style=""/> 
			
		</a> if on execute else display nothing-->
		<?php	
			//$result = $wpdb->get_results ( "SELECT * FROM radio_time" );
			
			//foreach ( $result as $print )   {
			
			//}
			//echo $play_offline;
			
			if($play_offline==1){
			?>
			<div class="leftofficelinradioplayer">
				
				<iframe src="http://careandcure.co.uk/cc_files/radiooffline_player.php" style="width:143px;overflow:hidden;" scrolling="no"  ></iframe> 
				
			</div>	
			
			<!--<div  >
				<?php include_once('radiooffline_player.php');?>
				<a class="leftofficelinradio radioleftoffline fancybox.iframe  " style=" " target="_blank" href="<?php echo get_site_url(); ?>/cc_files/radiooffine.php">	Offline Radio</a>
			</div>	-->
			<?php
			}
		?>
		<?php 
			
			global $current_user;
			get_currentuserinfo();
			$user_id='';
			//echo $current_user->ID.'-----------------------';
			if(isset($current_user->ID) && $current_user->ID!=0)
			{
			?>
			<div>
				
				<!--<a class="leftofficelinradiologin  "   href="<?php echo get_site_url(); ?>/index.php/my-account/?temp=radio">Login to  Media Library</a>-->
				<a class="leftofficelinradiologin  "   href="http://careandcure.co.uk/index.php/media-library/">Click to Media Library</a>
			</div>	
			
			<?php 
			}
			else
			{
			?>
			<div>
				
				<!--<a class="leftofficelinradiologin simplemodal-login"   href="<?php echo get_site_url(); ?>/index.php/my-account/?temp=radio">Login to  Media Library</a>-->
				<a class="leftofficelinradiologin  "   href="http://careandcure.co.uk/index.php/media-library/">Click to Media Library</a>
				
			</div>	
			<?php 
			}
			
		?>
		
		<!--
			<a class="leftofficelinkradiofeed" href="<?php echo get_site_url(); ?>/index.php/my-account/?temp=radio"  > 		
			Offline Radio  Listening
			
			
			</a>
		-->
	</div>
	
	<?php 
		
		
	} 
	else if($radion_live=="true")
	
	{
	?>
	
	<a class="leftboxorangeradiousappointment  radiorightappointment2 fancybox.iframe  " href="http://station.voscast.com/58e20c7890e2c/"  href="javascript:void(0)"  > 		
		<div id="radioimage"  style="color:red;font-weight:bold;font-size:14px;display:none">Live Radio</div>
		<img style="    padding-left: 28px;width:16px" src="http://careandcure.co.uk/cc_files/radio.png" style=""/> 
		<div>
			<iframe src="http://station.voscast.com/58e20c7890e2c/" style="    width: 235px;
			height: 174px;
			margin-left: -82px;
			margin-top: -15px;
			overflow: hidden;"scrolling="no"  frameBorder="0"></iframe> 
			
			
			
		</div>
		
		
		
	</a>
	
	<!--
		<a class="leftboxorangeradiousappointment  radiorightappointment2 fancybox.iframe  " href="http://www.panjabradio.co.uk/audio.html"  href="javascript:void(0)"  > 		
		<div id="radioimage"  style="color:red;font-weight:bold;font-size:14px">Live Radio</div>
		<img style="    padding-left: 28px;width:16px" src="http://careandcure.co.uk/cc_files/radio.png" style=""/> 
		<div>
		<iframe src="http://www.panjabradio.co.uk/audio.html" style="width:74px;height:48px;"></iframe> 
		
		
		
		</div>
		
		
		
	</a>-->
	<?php 
	}
	
}

?>





<!--
	<div id="radiotest"> 
	<div class="cc_player" data-username="venujakku">Loading ...</div>
	<script language="javascript" type="text/javascript" src="https://control.internet-radio.com:2199/system/player.js"></script>
	
	</div>
	<a class="leftboxorangeradiousappointment  radiorightappointment fancybox various" href="#radiotest"  href="javascript:void(0)"  > 		
	
	<img id="radioimage" src="cc_files/radio.png" style="width:32px"/>
	
	
</a>---> 
<style>
	
	#radioimage {
	animation: blink 1s linear infinite;
	}
	
	@keyframes blink {  
	50% { opacity:0.1; }
	}
	
	.zindex
	{
	z-index:99999;
	}
</style>


<script type='text/javascript' src='https://www.doubango.org/click2dial/c2c-api.js'></script>
<script type='text/javascript'>
	/*c2c.from = 'c2hhaDU1NTg5QGdtYWlsLmNvbQ==';
		c2c.text = '<strong>Call us free now </strong>&raquo;';
		c2c.cls = 'rightcallusbutton btn btn-large btn-success ';
		c2c.config = {
		http_service_url: 'https://webrtc.sipthor.net/#!/call/sam5589@sip2sip.info',
		websocket_proxy_url: null,
		sip_outbound_proxy_url: 'proxy.sipthor.net'
		};
		c2c.init();
	*/
</script>

<script type="text/javascript">
	jQuery( document ).ready( function( $ ) {
		
		
		$('#comments').hide();
		$('.comment_pager').hide();
		$('.comment_form').hide();
		$('.post_info').hide();
		
		
		//blink(900000, 1000);
		
		/*
			function blink(time, interval)
			{
			var timer = window.setInterval(function(){
			$("img").css("opacity", "0.1");
			window.setTimeout(function(){
			$("img").css("opacity", "1");
			}, 100);
			}, interval);
			window.setTimeout(function(){clearInterval(timer);}, time);
		} */
		/*
			*  Simple image gallery. Uses default settings
		*/
		var mCarouselTO = setTimeout(function(){
			var mCarouselTO3333 = setInterval(function(){
				//alert("")
				$('#caroufredsel-next').trigger('click');
			}, 2000);
			//$('.blog_slides').carousel('cycle');
		}, 8000);
		$('.fancybox').fancybox();
		
		
		$(".various").fancybox({
			maxWidth	: 800,
			maxHeight	: 600,
			fitToView	: false,
			width		: '70%',
			height		: '70%',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'none',
			closeEffect	: 'none'
		});
		$(".ccappointmentbutton").fancybox({
			maxWidth	: 900,
			maxHeight	: 700,
			fitToView	: false,
			width		: '65%',
			height		: '350px',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'elastic',
			closeEffect	: 'elastic'
		});
		$(".ccaskourexpertbutton").fancybox({
			maxWidth	: 900,
			maxHeight	: 700,
			fitToView	: false,
			width		: '65%',
			height		: '350px',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'elastic',
			closeEffect	: 'elastic'
		});
		$(".ccaskourexpertbuttonright").fancybox({
			maxWidth	: 900,
			maxHeight	: 700,
			fitToView	: false,
			width		: '65%',
			height		: '350px',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'elastic',
			closeEffect	: 'elastic'
		});
		$(".ccaskourexpertbuttonrightappointment").fancybox({
			maxWidth	: 900,
			maxHeight	: 700,
			fitToView	: false,
			width		: '65%',
			height		: '350px',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'elastic',
			closeEffect	: 'elastic'
		});
		
		$(".radiorightappointment").fancybox({
			maxWidth	: 900,
			maxHeight	: 700,
			fitToView	: false,
			width		: '200px',
			height		: '80px',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'elastic',
			closeEffect	: 'elastic'
		});
		$(".radiorightappointment2").fancybox({
			maxWidth	: 900,
			maxHeight	: 700,
			fitToView	: false,
			width		: '360px',
			height		: '280px',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'elastic',
			closeEffect	: 'elastic'
		});
		$(".radioleftoffline").fancybox({
			maxWidth	: 900,
			maxHeight	: 700,
			fitToView	: false,
			width		: '450px',
			height		: '180px',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'elastic',
			closeEffect	: 'elastic'
		});
		$(".ccappointmentbuttondb").fancybox({
			maxWidth	: 900,
			maxHeight	: 700,
			fitToView	: false,
			width		: '65%',
			height		: '350px',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'elastic',
			closeEffect	: 'elastic'
		});
		$(".ccaskourexpertbuttondb").fancybox({
			maxWidth	: 900,
			maxHeight	: 700,
			fitToView	: false,
			width		: '65%',
			height		: '350px',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'elastic',
			closeEffect	: 'elastic'
		});
	});
	
	
	
	<?php 
		if ( current_user_can( 'Dradmin' ) ) {
		?>
		
		// $('#adminmenuwrap').hide();
		<?php 
		}
		
	?>
	
	function openyoutube()
	{//alert("");
		
		$('#1111').fancybox().trigger('click');
		
		
	}
	
	
	
	</script>
	
	<!--
	
	<a class="various fancybox.iframe" id="1111" href="http://www.youtube.com/embed/L9szn1QQfas?autoplay=1">Youtube (iframe)</a>
	
	<a  href="javascript:openyoutube()">Youtube (iframe)yyyyyyyyyyyyyy</a>
	<a class="various" data-fancybox-type="iframe" href="http://www.youtube.com/embed/L9szn1QQfas?autoplay=1">Iframe</a>
	
	-->												