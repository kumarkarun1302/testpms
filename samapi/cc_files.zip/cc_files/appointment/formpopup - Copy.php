<?php 
	require( '../../wp-load.php' );
		
	
	?>
<!DOCTYPE html>
<!--[if IE 7]><html class="ie ie7" lang="en-US"><![endif]-->
<!--[if IE 8]><html class="ie ie8" lang="en-US"><![endif]-->
<!--[if !(IE 7) | !(IE 8) ]><!-->
<html lang="en-US">
	<!--<![endif]-->
	<head>
		<!-- META TAGS -->
		<meta charset="UTF-8">
		 <link rel='stylesheet' id='bootstrap-css-css'  href='<?php echo get_home_url();?>/cc_files/css/main.css' type='text/css' media='all' />
		 <link rel='stylesheet' id='main-css-css'  href='<?php echo get_home_url();?>/cc_files/css/bootstrap.css' type='text/css' media='all' />
		 
		
		<!-- END GADWP Universal Tracking -->
		
	 
	<body class="page-template  ">
	 
	 
		
		<div class="appoint-page clearfix" style="padding:0px">
			<div class="container">
				
				
				
				<div class="row">
					<div class="col-lg-10 col-md-10 col-sm-10 col-lg-offset-1 col-md-offset-1 col-sm-offset-1">
						<div class="appoint-section clearfix">
							<div class="top-icon"><img src="<?php echo get_home_url();?>/cc_files/images/appoint-form-top.png" alt=""/></div>
							<form id="appointment_form_main" action="<?php echo get_home_url();?>/cc_files/appointment/formpopupsubmit.php" method="post">
								<div style="color:green;font-weight:bold"><?php 
				
				if(isset($_GET["status"]))
				{
					if($_GET["status"]=='success')
					{
						
						echo 'Thank you for Information';
						
						}
					
					}
				?>
				</div>
								<div class="row">
									<div class="col-lg-6 col-md-6 col-sm-12 ">
										<input type="text" name="name" id="app-name" required class="required" placeholder="Name" title="* Please provide your name"/>
									</div>
									<div class="col-lg-6 col-md-6 col-sm-12 ">
										<input type="text" name="number" id="app-number" required placeholder="Phone Number" title="* Please provide your phone number."/>
									</div>
								</div>
								
								<div class="row">
									<div class="col-lg-6 col-md-6 col-sm-12 ">
										<input type="email" name="email" id="app-email" required class="required email" placeholder="Email Address" title="* Please provide a valid email address"/>
									</div>
									<div class="col-lg-6 col-md-6 col-sm-12 ">
										<input type="date" name="date" id="datepicker" min="<?php echo date('Y-m-d');?>" required placeholder="Appointment Date"/  title="* Please provide appointment date">
									</div>
								</div>
								
								<div class="row">
									<div class=" col-lg-12 col-md-12 col-sm-12">
									<textarea name="message" id="app-message" required class="required" cols="50" rows="1" placeholder="Message" title="* Please provide your message"></textarea>
									 
							</div>
						</div>
						
                        
                        <div class="row">
                            <div class="col-sm-12">
                                <input type="submit" name="Submit" class="btn" value="Submit Request"/>
                                <img src=" " id="appointment-loader" alt="Loading...">
							</div>
							
                            <div class="col-sm-12">
                                <div id="message-sent"></div>
                                <div id="error-container"></div>
							</div>
							
						</div>
						
					</form>
				</div>
			</div>
		</div>
		
	</div>
</div>
<script>
	
	document.getElementById('scb-wrapper').style.display="none";
</script>

</body>
</html>