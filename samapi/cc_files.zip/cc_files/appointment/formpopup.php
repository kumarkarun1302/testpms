<?php 
	//require( '../../wp-load.php' );
	include_once('../custom.php');
	
	?><?php 
	//require( '../../wp-load.php' );
	
	
?>
<!DOCTYPE html>
<!--[if IE 7]><html class="ie ie7" lang="en-US"><![endif]-->
<!--[if IE 8]><html class="ie ie8" lang="en-US"><![endif]-->
<!--[if !(IE 7) | !(IE 8) ]><!-->
<html lang="en-US">
	<!--<![endif]-->
	<head>
		<!-- META TAGS -->
		<meta charset="UTF-8">
		<link rel='stylesheet' id='bootstrap-css-css'  href='<?php echo $url;?>/cc_files/css/main.css' type='text/css' media='all' />
		<link rel='stylesheet' id='main-css-css'  href='<?php echo$url;?>/cc_files/css/bootstrap.css' type='text/css' media='all' />
		<link rel='stylesheet' id='datepicker-css-css'  href='<?php echo$url;?>/cc_files/css/datepicker.css' type='text/css' media='all' />
		<link rel='stylesheet' id='datepicker-css-css'  href='http://fontawesome.io/assets/font-awesome/css/font-awesome.css' type='text/css' media='all' />
		
		<script type='text/javascript' src='<?php echo$url;?>/cc_files/js/jquery.js'></script>
		
		
		<body class="page-template  ">
			
			
			
			<div class="appoint-page1 clearfix" style="padding:0px">
				<div class="container" style="width:100%">
					<div class="row">
						<div id="appointment_form_three" class="col-lg-8 col-md-8 col-sm-12 " >
							<div class="slogan-section animated fadeInUp clearfix ae-animation-fadeInUp" style="margin-bottom:10px;">
								<div class="col-md-3 col-xs-3" style="background: #68893d;">
									
									<img src="http://www.careandcure.co.uk/wp-content/uploads/2016/11/careandcure-logo.gif" style="width:95px"> 
								</div>
								<div class="col-md-9 col-xs-9" style="background: #68893d;">
								<h2 style="    color: #FFF;padding-top:10px;margin-bottom: 10px;text-align:left   "><i class="fa fa-user-md" aria-hidden="true"></i> Make an Appointment</h2>  </div>
								
							</div>
							<div class="appointment-form animated fadeInDown clearfix ae-animation-fadeInDown">
								<form class="row" id="s" action="<?php echo $url;?>/cc_files/appointment/formpopupsubmit.php" method="post"  >
									
									<div style="color:green;font-weight:bold"><?php 
										
										if(isset($_GET["status"]))
										{
											if($_GET["status"]=='success')
											{
												
												echo 'Message has been sent, an expert will get back to you asap. Thank you ';
												?>
												
												<script>
												
												//alert('Message has been sent, an expert will get back to you asap. Thank you ');
												</script>
												<?php 
											}
											
										}
									?>
									</div>
									<div class="col-lg-6 col-md-6 col-sm-6">
										<input type="text" name="name" id="app-name" required class="required" placeholder="Name" title="* Please provide your name">
									</div>
									<div class=" col-lg-6 col-md-6 col-sm-6">
										<input type="text" name="number" maxlength="15" id="app-number" required placeholder="Phone Number" title="* Please provide a valid phone number.">
									</div>
									
									<div class=" col-lg-6 col-md-6 col-sm-6">
										<input type="email" name="email" id="app-email" required class="required email" placeholder="Email Address" title="* Please provide a valid email address">
									</div>
									<div class=" col-lg-6 col-md-6 col-sm-6">
										
										<input type="text" name="date"  required id="datepicker" placeholder="Appointment Date" title="* Please provide appointment date">
										
										
										
									</div>
									
									
									
									
									
									
									
									
									<div class=" col-lg-12 col-md-12 col-sm-12">
										<textarea name="message" id="app-message" required cols="50" rows="1" placeholder="Question" title="* Please provide your message" style="overflow: hidden; word-wrap: break-word; resize: none; height: 47px;"></textarea>
									</div>
									<div class=" col-lg-6 col-md-6 col-sm-6 col-xs-6  text-right">
										
										<script src='https://www.google.com/recaptcha/api.js'></script>
										
										<div class="capcha-box" style=" ">
											
											
											<div class="g-recaptcha" data-callback="onReturnCallback" data-sitekey="6Lf4tREUAAAAAOh_FxSXlmkFGt4R7T-n3S4W8tZt"
											
										></div></div>
										<input value="" required type="text" id="gvalidate" width="0px" style=" margin-top: -50px; position: absolute;  width: 0px;  float: left;  margin-left: -256px;  z-index: -9999;  border: 1px solid #FFF;"/>
										<script>
										
										
											var onReturnCallback = function(response) { 
												// alert('g-recaptcha-response: ' + grecaptcha.getResponse()); 
												jQuery('#gvalidate').val(grecaptcha.getResponse());
												
											 
												
												// gvalidate
												
											}; // end of onReturnCallback 
											
										</script>
									</div>
									<div class=" col-lg-6 col-md-6 col-sm-6  col-xs-6  text-right">
										<input type="submit" name="Submit" class="btn" value="SCHEDULE APPOINTMENT">
										
										
									</div>
									
								</form>
							</div>
						</div>
					</div>
					
					
					
					
				</div>
			</div>
			<script>
				
				document.getElementById('scb-wrapper').style.display="none";
			</script>
			
			
			
			
			
			
			
		<script type='text/javascript' src='<?php echo $url;?>/cc_files/js/datepicker.min.js'></script>
		
		
		<script type='text/javascript' src='<?php echo $url;?>/cc_files/js/date_custom.js'></script>
		
		 
		
		</html>							