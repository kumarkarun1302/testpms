<?php
	
	
	$captcha = $_POST['g-recaptcha-response'];//"03AHJ_VuvRdDTYYvUf6UpnORHNPOI3Fq__jLboijLyE-k8PE_1y6bP5J7iMk4JLvP56LfOc3kMy9cLch2-Qpae21PzGWRBUgCHGE-vPr1ZUvvVNGJw6_8pEHp-drLmuHWHtdJt8bDvvO_Mzd9vIrkw6ou0MWjfhorXzz1D1RYgK9kDEJLi09EOAqMNKlLlH77Wej0x3UbxPj1FWopjCZf6BBb6MPjXRjHvsCkyvC97F4W6hiSWEUX1BIUIX2q9dxjmpeXsAMT2RISJplNyoAhFY0wC5bMd3EoLQrtvVHc4htU2DYqBMKlrnmZV8damqKvmO7oVvngCsPpjzV1TV-VO4op6sTw032yRU8prrVhhtBS2D4KOIUEWIuTp6zuAwuKK3xkq5JkU74LkuONPy9rSwzJjkfi59CyU9B8DU419SF8xPnDCAvJ4hx68OeLBJ-Lot2wlZ1hvSik41utIoSuYo8oeuYOOwWP0aS7nBEzRVVDWUvUroRVqydWKyoRghaO69nwMowkO6p2fuEfF0FeCMH6xUcashMhibGDFOl1Cl4s3fnWchN3eHSDX6zvn16eOgyMgCWxVV8e-n8z_9uVY6D-3BD58Qan3-T_G2_AcUFXPLRy9Ffdcby1QYHL8GTpcO6cGRQX9s1CzMxD3A5m51vIZ5KsVX32pjtxYW_PTbfoBLeGWMNTaX3WYueCV1ayw3aTPAlA8Et32eCPwfVCCo1F8ouI5v4GHYKGAbXdFFm5TgzHsRk4N2osA5W_7H7yAGFrku8mKKfZX0a-dJHN1z5l7XQ6yRVcK2twumy27o96X2rEkZ2YoaWojbJuWGJEQU1jyCqhfb6-AwFc_Izqq7OrtefG9BgbFhzwDMEO33EyX5BcHZwrd2ovff-0pZYcCSYJ8UOKoFT8BNHYrRCvzf-6CONps9juBF6pmG-JC7oIad0Q2lgZJdKP0lj0bEh_-DDPW-rYbOGTP";
	
	if (!$captcha)
	{ 
		
		exit;
	}
	
	$secret = "6Lf4tREUAAAAAOsMopt93PvviLx-B2_g2qRJTrMK";//live
	
	$response = json_decode(file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$captcha."&remoteip=".$_SERVER["REMOTE_ADDR"]), true);
	//$response["success"]='true';
	//print_r($response);
	
	
	if($response["success"]!='true')
	{
		
		
		exit;
		
	}
	else
	{   $from='info@careandcure.com' ;   
		$headersfrom='';
		$headersfrom .= 'MIME-Version: 1.0' . "\r\n";
		$headersfrom .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headersfrom .= 'From: '.$from.' '. "\r\n";
		$headersfrom .= 'cc: info@careandcure.com '. "\r\n";
		$headersfrom .= 'bcc:admin@careandcure.co.uk, itsupport5589@gmail.com '. "\r\n";
		 
		
		$name=$_POST["name"];
		$number=$_POST["number"];
		$email=$_POST["email"];
		 
		$message=$_POST["message"];
		
		
		if($name !="" &&  $number !="" &&  $email !="" &&     $message !=""  )   
		{
			
			 
			
			require( '../../wp-load.php' );
			
			global $current_user;
			get_currentuserinfo();
			$user_id='';
			if(isset($current_user->ID))
			{
				$user_id=$current_user->ID;
			}
			
			if($user_id=='')
			{
				
				$user_id = username_exists( $email );
				
				
				
				
				
				if ( $user_id=='' ) 
				{
					
					$user_id = email_exists( $email );
					if ( $user_id=='' ) 
					{
						
						
						echo 'User Id is Empty</br/>';
						$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
						//echo '<br/> Email id Not  Exist '.$random_password;
						
						$userdata = array(
						'user_login'  => $email,
						
						'user_pass'   => $random_password, // When creating an user, `user_pass` is expected.
						'first_name'   =>  $name ,//  
						'user_email' =>   $email,
						'display_name' =>   $name ,
						'nickname' =>   $name ,
						'user_nicename' =>  $name
						);
						
						
						//$uid = wp_create_user(  $_POST['clientEmail'],$random_password,$values[2]['value']);
						
						$user_id = wp_insert_user($userdata);
						
						$reggistermail_content= '<table style="width: 600px; font-size: 11px; border-collapse: collapse;">
						
						<tr>
						
						
						
						<td colspan="2" style="width: 200px; font-weight: bold; border: 1px solid #eee; padding: 10px;">Your Account Information</td>
						
						
						
						
						
						</tr>
						
						<tr>
						
						
						
						<td style="width: 200px; font-weight: bold; border: 1px solid #eee; padding: 10px;">Username</td>
						
						<td style="border: 1px solid #eee; padding: 10px;">'. $email .'</td>
						
						
						
						</tr>
						<tr>
						
						
						
						<td style="width: 200px; font-weight: bold; border: 1px solid #eee; padding: 10px;">Password</td>
						
						<td style="border: 1px solid #eee; padding: 10px;">'. $random_password .'</td>
						
						
						
						</tr>
						<tr>
						
						
						
						<td style="width: 200px; font-weight: bold; border: 1px solid #eee; padding: 10px;">Login Link</td>
						
						<td style="border: 1px solid #eee; padding: 10px;"><h2 class="title" style="text-align: center;">
						
						<a href="'.get_home_url().'/index.php/login/" style="    color: #a01b11;">Login</a>
						</h2>
						</td>
						
						
						
						</tr>
						
						</table>';
						
						$subject='Careandcure - New account info';
						
						//$to=  'venujakku@gmail.com';
						
						$to=  ''.$email;
						//$to=  'venujakku@gmail.com,'.$email;
						 
						mail($to,$subject,$reggistermail_content,$headersfrom);
						
						
						
						//print_r($user_id);
						if(!is_array($user_id))
						{
							
						}
						else
						{
							$user_id='';
						}
						
					}
					
				}
				
			}
			
			
			
			
			
			
			
			$sqlquery="INSERT INTO questions(user_id,name,phone_number,emailid,question,created_datetime)
			
			values
			(
			'".str_replace("'","''",$user_id)."'
			,'".str_replace("'","''",$name)."'
			,'".str_replace("'","''",$number)."'
			,'".str_replace("'","''",$email)."'
			 
			,'".str_replace("'","''",$message)."'
			,'".date('Y-m-d H:i:s')."'
			
			)
			
			";
			$wpdb->query($sqlquery);
			 
			
			
			$reggistermail_content= '<table style="width: 600px; font-size: 11px; border-collapse: collapse;">
			
			<tr> 
			<td colspan="2" style="width: 200px; font-weight: bold; border: 1px solid #eee; padding: 10px;">Appointment Information </td>
			
			</tr> 
			<tr> 
			<td style="width: 200px; font-weight: bold; border: 1px solid #eee; padding: 10px;">First Name</td> 
			<td style="border: 1px solid #eee; padding: 10px;">'. $name .'</td> 
			</tr>
			
			<tr> 
			<td style="width: 200px; font-weight: bold; border: 1px solid #eee; padding: 10px;">Number</td> 
			<td style="border: 1px solid #eee; padding: 10px;">'. $number .'</td> 
			</tr>
			
			<tr> 
			<td style="width: 200px; font-weight: bold; border: 1px solid #eee; padding: 10px;">Email</td> 
			<td style="border: 1px solid #eee; padding: 10px;">'. $email .'</td> 
			</tr>
			
			 
			
			<tr> 
			<td style="width: 200px; font-weight: bold; border: 1px solid #eee; padding: 10px;">Message</td> 
			<td style="border: 1px solid #eee; padding: 10px;">'. $message .'</td> 
			</tr>
			
			</tr>
			
			
			
			
			'; 
			
			$reggistermail_content=$reggistermail_content.'</table>';
			
			//echo $reggistermail_content;
			$subject='Careandcure - Ask Our Expert info';
			
			//$to=  'venujakku@gmail.com';
			
			$to=  ''.$email;
			//$to=  'venujakku@gmail.com,'.$email;
			
			
			$from='info@careandcure.com' ;   
			
			
			//echo $reggistermail_content;
			if($name!='')
			mail($to,$subject,$reggistermail_content,$headersfrom);
			
			
			
			//- Mail to user //request for app or question has been received and it will b answered soon
			$to=$email;
			$subject="Request for question  has been received and it will be answer soon";
			$content='<table style="width: 600px; font-size: 11px; border-collapse: collapse;">
			
			<tr> 
			<td colspan="2" style="width: 200px; font-weight: bold; border: 1px solid #eee; padding: 10px;">
			
			'.$subject.'
			</td>
			
			</tr> 
			
			</table>';
			
			//$reggistermail_content=$content.$reggistermail_content;
			
			mail($to,$subject,$content,$headersfrom);
			
		}
		 ob_clean();
		 header('location:formpopupquestions.php?status=success');
		
	}
?>										