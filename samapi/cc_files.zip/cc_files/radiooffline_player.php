<?php 
	
	
	
	
	define('DB_NAME', 'careandc_wrdp2');
	
	
	define('DB_USER', 'careandc_wrdp2');
	
	
	define('DB_PASSWORD', 'K4pOaX3v27gVMTR7');
	
	define('DB_HOST', 'localhost');
	
	/*
		define('DB_NAME', 'careandcure');
		
		
		define('DB_USER', 'root');
		
		
		define('DB_PASSWORD', 'venu');
		
		
		define('DB_HOST', 'localhost');
		
	*/
	
	$servername = DB_HOST;
	$username =DB_USER;
	$password =DB_PASSWORD;
	$dbname =DB_NAME;
	
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	
?>

<?php 
	
	
	
	//$sql = "SELECT * FROM radio_feeds ORDER BY created_datetime DESC limit 0,1";
	$sql2 = "SELECT * FROM radio_time   LIMIT 0,1";
	$result2 = $conn->query($sql2);
	if ($result2->num_rows > 0) {
		while($row2 = $result2->fetch_assoc()) {
		?>
		<div id="radioimage"  style="color:#FFF;font-weight:bold;font-size:11px;<?php if(isset($_GET["page"])) echo 'text-align:center';?>">Next Live Show : <?php echo $row2['day'].' at '.$row2['start_time'].':00 hrs UK' ;?></div>
		<br/>
		
		<?php 
		}
	}
	
?>

<?php 
	//$sql = "SELECT * FROM radio_feeds ORDER BY created_datetime DESC limit 0,1";
	$sql = "SELECT * FROM radio_feeds WHERE play='1' LIMIT 0,1";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) { 
		// output data of each row
		while($row = $result->fetch_assoc()) {
			
			//echo $row['id'];
		?>
		
		
		<audio controls <?php if(isset($_GET["page"])) if($_GET["page"]=='Home') echo 'autoplay';?> loop <?php if(isset($_GET["source"])) echo 'style="width:100%"';?> >
			
			<source   src="http://careandcure.co.uk/radiofeeds/<?php echo $row["id"];?>.mp3" type="audio/mpeg">
			
		</audio>
		
		<div id="mask"></div>
		
		
		<style>
			<?php 
				if(isset($_GET["source"]))
				{?>
				
				audio::-webkit-media-controls-panel{ 
				color:#FFF;
				background-color:  #709724;
				}
				audio::-webkit-media-controls-panel
				,audio::-webkit-media-controls-mute-button
				,audio::-webkit-media-controls-current-time-display
				,audio::-webkit-media-controls-play-button
				,audio::-webkit-media-controls-time-remaining-display
				,audio::-webkit-media-controls-volume-slider
				,audio::-webkit-media-controls-mute-button
				
				,audio::-webkit-media-controls-play-button
			
			,audio::-webkit-media-controls-timeline-container
			
			,audio::-webkit-media-controls-current-time-display
			
			,audio::-webkit-media-controls-time-remaining-display
			
			,audio::-webkit-media-controls-timeline
			
			,audio::-webkit-media-controls-volume-slider-container
			
			,audio::-webkit-media-controls-volume-slider
			
			,audio::-webkit-media-controls-seek-back-button
			
			,audio::-webkit-media-controls-seek-forward-button
			
			,audio::-webkit-media-controls-fullscreen-button
			
			,audio::-webkit-media-controls-rewind-button
			
			,audio::-webkit-media-controls-return-to-realtime-button
			
			,audio::-webkit-media-controls-toggle-closed-captions-button
			{
			color:#FFF;
			
			}
			
			audio /deep/ input[type=range] {
			background-color: #709724;
			}
			<?php 
			
			
			}
			
			
			?>
			
			
			
			
			audio::-internal-media-controls-download-button {
			display:none;
			}
			
			audio::-webkit-media-controls-enclosure {
			overflow:hidden;
			}
			
			audio::-webkit-media-controls-panel {
			width: calc(100% + 30px); /* Adjust as needed */
			}
			
			</style> 
			<style>
			
			#radioimage {
			animation: blink 1s linear infinite;
			color:#FFF;
			}
			
			@keyframes blink {  
			50% { opacity:0.2; }
			}
			
			.zindex
			{
			z-index:99999;
			}
			</style>
			<?php 
			}
			} else {
			
			}
			$conn->close();
			
			?>			